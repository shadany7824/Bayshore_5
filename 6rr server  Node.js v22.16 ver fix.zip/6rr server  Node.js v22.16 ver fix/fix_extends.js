const fs = require('fs');
const path = require('path');

// Define directory to fix
const distDir = path.join(__dirname, 'dist');

// Old __extends code snippet
const oldExtends = `    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };`;

// New __extends code snippet (compatible with Node.js v22)
const newExtends = `    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { 
            Object.defineProperty(this, 'constructor', {
                value: d,
                writable: true,
                configurable: true
            });
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };`;

// Recursively search for all JS files in directory
function findJsFiles(dir) {
    let results = [];
    const list = fs.readdirSync(dir);
    
    list.forEach(file => {
        const filePath = path.join(dir, file);
        const stat = fs.statSync(filePath);
        
        if (stat && stat.isDirectory()) {
            // Recursively search subdirectories
            results = results.concat(findJsFiles(filePath));
        } else if (path.extname(file) === '.js') {
            // If JS file, add to results list
            results.push(filePath);
        }
    });
    
    return results;
}

// Fix all JS files
function fixJsFiles() {
    const jsFiles = findJsFiles(distDir);
    let fixedCount = 0;
    
    jsFiles.forEach(filePath => {
        try {
            // Read file content
            let content = fs.readFileSync(filePath, 'utf8');
            
            // Check if file contains code that needs fixing
            if (content.includes(oldExtends)) {
                // Replace code
                content = content.replace(oldExtends, newExtends);
                
                // Write modified content
                fs.writeFileSync(filePath, content, 'utf8');
                console.log(`Fixed file: ${filePath}`);
                fixedCount++;
            }
        } catch (error) {
            console.error(`Error processing file ${filePath}:`, error);
        }
    });
    
    return fixedCount;
}

// Execute fix
console.log('Starting JS file fixes...');
const fixedCount = fixJsFiles();
console.log(`Fix complete! Fixed ${fixedCount} files.`); 